class name {
    constructor(parameters) {
        
    }
}