console.log("//for the  full copyright and license information, please view the CONTRIBUTERS.MD//for the html file, please open thomas.html and view the style.css file in the same directory//images are included in the images directory//for more information please visit the website and A&Q//this is thhe beta release of the game dropping balls//start of js");

//for the  full copyright and license information, please view the CONTRIBUTERS.MD
//for the html file, please open thomas.html and view the style.css file in the same directory
//images are included in the images directory
//for more information please visit the website and A&Q
//this is the beta release of the game "dropping balls
//start of js

"use strict";

//variable declarations

const px = "px";
let acclasser = 'l';
let classer = 1;
let l1 = document.getElementsByClassName(acclasser + classer)[0];
let rightaid = 0;
let acrightaid = 39;
let acleftaid = -41;
let acpoints = 0;
let pointcalc = 20;
let per = 0;
let level = 0;
let moneyac = 0;
let levelbar = document.querySelector(".barcontainer")
let money = document.querySelector(".levelbarper");
function update_point() {
  money.textContent = moneyac  + "%";
}

function　updatebar(){
  addpoints();
  calcpoints();
  levelbar.style.width = per + px;
  calcpoints();
  update_point();
}

function addpoints(){
  acpoints++;
  per = per + 5;
  moneyac = moneyac + 5;
  return [per, acpoints];
}
function calcpoints() {
  if (acpoints === pointcalc) {
    money++;
    moneyac = 0;
    return [money, moneyac];
}
}



const standardm = 5;
const standardmac = 5;
let ok = null;



let acrandom;

l1 = document.getElementsByClassName("l1")[0];


//ball level and spawn variables
let aclevel = 16;
let ralevel = 1;
let random = Math.floor(Math.random() * 2048);

//constants
//balls
//balls (small)
let tier = 'tier';
let smallballs = {};

for (let i = 1; i <= 12; i++) {
  let key = Math.pow(2, i-1);
  smallballs[`${tier}${i}`] = key;
}

console.log(smallballs);

// ball (k)

let kballs = {};
let thousands = "k";
for (let i = 3; i <= 12; i++) {
  let keys = Math.pow(2, i-1);
  kballs[`${tier}${i}`] = `${keys}${thousands}`;
}


console.log(kballs);


//ball (m)


let mballs = {};
let millions = "m";
for (let i = 3; i <= 12; i++) {
  let keyss = Math.pow(2, i-1);
  mballs[`${tier}${i}`] = `${keyss}${millions}`;
}


console.log(mballs);

//ball (b)
let bballs = {};
let billinos = "b";
for (let i = 3; i <= 12; i++) {
  let keysss = Math.pow(2, i-1);
  bballs[`${tier}${i}`] = `${keysss}${billinos}`;
}

console.log(bballs);

//ball (t)
let tballs = {};
let trillions = "t";
for (let i = 3; i <= 12; i++) {
  let keyssss = Math.pow(2, i-1);
  tballs[`${tier}${i}`] = `${keyssss}${trillions}`;
}

console.log(tballs);

//ball (q)
let qballs = {};
let qintillon = "q"; //quad
for (let i = 3; i <= 12; i++) {
  let keysssss = Math.pow(2, i-1);
  qballs[`${tier}${i}`] = `${keysssss}${qintillon}`;
}

console.log(qballs)

//ball dimensions
let dimensions = {};
let levelss = "level";
let standardn = 50;
for (let i = 1; i <= 12; i++) {
  let kkeys = standardn + (i * 4);
  dimensions[`${levelss}${i}`] = `${kkeys}`;
}

let tierac = 2;

let toppx = -95;

function calctoppx() {

}

let keyer = 1;
let classnamer = {};
let baller = "l";
let classnameac 
function addname() {
  keyer++;
  classnamer[`${baller}${keyer}`] = `${baller}${keyer}`;
  classnameac = classnamer[`${baller}${keyer}`];
  return;
}

let ballstyles = {
  'borderRadius': "50%",
  'position': "absolute",
  'display': "inline-block",
  'textAlign': "center",
  'verticalAlign': "middle",
  'top': toppx + 'px',
  'border': "none"
}

let l1style = {
  'backgroundColor': "aqua",
  'position': "relative",
  'height': "50px",
  'width': "50px",
  'right': "200px",
  'left': "200px",
  'top': "-25px",
  'border': "none"
}

addname();

let tiers = {};
tiers[`smallballs`] = smallballs;
tiers[`kballs`] = kballs;
tiers[`mballs`] = mballs;
tiers[`bballs`] = bballs;
tiers[`tballs`] = tballs;
tiers[`qballs`] = qballs;

let balltimes = 0;
let acballtimes = "ball";
let ballvars = {
  nothing: [null] 
};
function acballdefalter() {
  balltimes++;
  ballvars[`${acballtimes}${balltimes}`] = [null];
  ballvars[`${acballtimes}${balltimes}`][`bottom`] = 79;
  ballvars[`${acballtimes}${balltimes}`][`ballposleft`] = 205;
  ballvars[`${acballtimes}${balltimes}`][`rightaid`] = 0;
  ballvars[`${acballtimes}${balltimes}`][`acok`] = true;
  ballvars[`${acballtimes}${balltimes}`][`standardtop`] = 566;
  return;
}

function balldefalter() {
  acballdefalter();
  ballposleft = ballvars[`${acballtimes}${balltimes}`][`ballposleft`];
  bottom = ballvars[`${acballtimes}${balltimes}`][`bottom`];
  acok = ballvars[`${acballtimes}${balltimes}`][`acok`];
  rightaid = ballvars[`${acballtimes}${balltimes}`][`rightaid`];
  standardtop = ballvars[`${acballtimes}${balltimes}`][`standardtop`]
}
let libs = {};

for (let i = 1; i <= 3; i++) {
libs[`tierac${i}`] = {};
}

// for (let i = 1; i <= 3; i++){
// let thevar = i;
// tiers.smallballs[`tierac${i}`][`actier${i}`] = [smallballs[`${tier}${thevar}`], null]
// thevar++;
// tiers.smallballs[`tierac${i}`][`actier${i}`] = [smallballs[`${tier}${thevar}`], null]
// thevar++;
// tiers.smallballs[`tierac${i}`][`actier${i}`] = [smallballs[`${tier}${thevar}`], null]
// thevar++;
// tiers.smallballs[`tierac${i}`][`actier${i}`] = smallballs[`${tier}${thevar}`]
// thevar++;
// }
for (let i = 1; i <= 3; i++) {
 libs[`tierac${i}`][`actier${i}`] = [];
  for (let j = 1; j <= 4; j++) {
   libs[`tierac${i}`][`actier${i}`].push(Math.pow(2, j + (4 * (i - 1))));
  }
}


let currenttier = libs.tierac1.actier1;


// let thatacok = false;

// let acrandomer;


// function checkradom () {

// while (thatacok === false){
// let isPresent = false;

// for (const [tierKey, tierValue] of Object.entries(libs)) {
//   for (const [valueKey, value] of Object.entries(tierValue)) {
//     if (Array.isArray(value) && value.includes(random)) {
//       isPresent = true;
//       break;
//     }
//   }
//   if (isPresent) {
//     break;
//   }
// }

// if (isPresent) {
//   if (currenttier.includes(random)){
//     thatacok = true;
//     console.log(`${random} is present in the tiers.`);
//     acrandomer = random;
//     return random;
//   }
//   else{
//     console.log(`${random} is not present in the tiers.`);
//     random = Math.floor(Math.random() * 2048);
//   }
// } else {      
//   console.log(`${random} is not present in the tiers.`);
//   random = Math.floor(Math.random() * 2048);
// }
// }
// thatacok = false;
// random = Math.floor(Math.random() * 2048);
// return;
// }

// let pxer = 0.2;
// let smalllest = currenttier[0];
// let basepx = 50;

// function bigballch(){

// }
// let colors = {
//   "l1": "cyan",
//   "l2": "yellow",
//   "l3": "green",
//   "l4": "red",
//   "l5": "aqua",
//   "l6": "blueviolet",
//   "l7": "pink",
//   "l8": "crimson",
//   "l9": "darkgreen",
//   "l10": "blue",
//   "l12": bigballch()
// }

  // "tier1": "px",
  // "tier2": "px",
  // "tier3": "px",
  // "tier4": "px",
  // "tier5": "px",
  // "tier6": "px",
  // "tier7": "px",
  // "tier8": "px",
  // "tier9": "px",
  // "tier10": "px",
  // "tier12": "px",



// checkradom();
// checkradom();

let thatacok = false;
let acrandomer;

function changerand () {
  random = Math.floor(Math.random() * 2048);
}
function checkrandom() {
  while (thatacok === false) {
    let isPresent = false;

    for (const [tierKey, tierValue] of Object.entries(libs)) {
      for (const [valueKey, value] of Object.entries(tierValue)) {
        if (Array.isArray(value) && value.includes(random)) {
          isPresent = true;
          break;
        }
      }
      if (isPresent) {
        break;
      }
    }

    if (isPresent) {
      if (currenttier.includes(random)) {
        thatacok = true;
        console.log(`${random} is present in the tiers.`);
        acrandomer = random; 
        return random;
      } else {
        console.log(`${random} is not present in the tiers.`);
        random = Math.floor(Math.random() * 2048);
      }
    } else {
      console.log(`${random} is not present in the tiers.`);
      random = Math.floor(Math.random() * 2048);
    }
  }
  thatacok = false;
  return random;
}

function checkrand(){
let loops = 0;
let looper = true;
let acrandomr = 0;
function randch() {
  acrandomr = random;
  while (looper === true){
   acrandomr = acrandomr/2;
   looper = true;
   loops++;
   if (acrandomr === 1) {
    looper = false;
    return loops;
   }
  }
  return loops;
}

randch();
return loops;
}
let pxer = 0.2;
let smalllest = currenttier[0];
let basepx = 50;

function bigballch(className) {
  // document.querySelector()
}

let colors = {
  l1: "cyan",
  l2: "yellow",
  l3: "green",
  l4: "red",
  l5: "aqua",
  l6: "blueviolet",
  l7: "pink",
  l8: "crimson",
  l9: "darkgreen",
  l10: "blue",
  l12: bigballch(),
};

let currentlv = 1;
checkrandom();

setTimeout(() => {
  checkrandom();
}, 1000);

let wihi = {};
let unit = "wihi";
let base = 48;
let baseunit = 1;
for (let i = 1; i <= 4; i++){
    base = base + baseunit;
    wihi[`${unit}${i}`] = base;
}

let textclass;

function addball(className, tier, loops){
  // Step 1: Select the parent element
  const parentElement = document.querySelector('.ac');

  // Step 2: Create the new element
  const newElement = document.createElement('div');
  
  // Step 3: Optionally, add content or attributes
  // newElement.textContent = tier;
  newElement.setAttribute('class', className);
  const acparentElement = newElement;
  const acnewelement =  document.createElement('h2') ;
  newElement.style.verticalAlign = ballstyles.verticalAlign;
  newElement.style.top = ballstyles.top;
  newElement.style.border = ballstyles.border;
  newElement.style.borderRadius = ballstyles.borderRadius;
  newElement.style.zIndex = "9999";
  newElement.style.textAlign = "center";
  newElement.style.position = "relative"; 
  newElement.style.left = "200px"
  
  changerand();
  
  let acclass = className + 't';
  textclass = acclass;
  // Step 4: Append the new element to the parent element
      acnewelement.setAttribute('class', acclass)
      newElement.style.backgroundColor = colors[`l${loops}`];
      newElement.style.height = wihi[`wihi${loops}`] + px;
      newElement.style.width = wihi[`wihi${loops}`] + px;
      acnewelement.textContent = tier;
      acnewelement.style.top = wihi[`wihi${loops}`] - 43 + px;
      acnewelement.style.bottom = wihi[`wihi${loops}`] - 43 + px;
      acnewelement.style.position = 'relative';
  parentElement.appendChild(newElement);
  acparentElement.appendChild(acnewelement);
  classer++;
  return;
}

// function updateclasser() {
//   l1 = document.getElementsByClassName(acclasser + classer)[0];
//   return;
// }


let levelclass = {};
let balllevel = "level";
 for (let i = 1; i <= 4; i++){
   levelclass[`${balllevel}${i}`] = [null]
 }
let ballevel = "lv";
for (let i = 1; i <= 4; i++){
  levelclass[`${balllevel}${i}`][`${ballevel}${i}`] = [null];
}
//end of ball declarations
let xyzsw = 1;

//variable declarations for l1/other ball 's position
let ballposleft = 205;
let ballposright = 225;
let ballpostop = 31;
let standardtop = 566;
let rightcheck = 0;
let bottomcheck = 0;
let leftcheck = 0;
let acrightcheck = 646;
let acleftcheck = 835;
let topl;
let right;
let bottom;
let left;

let hu = document.querySelector("body").style.width;

//end of variable declarations
console.log(hu);

//start of the main
//start of function declaration
//Function to update the position variables based on the current ball position

function updatePositionVariables() {
  let ballElement = l1;
  let rect = l1.getBoundingClientRect();
  
  topl = rect.top;
  right = rect.right;
  bottom = rect.bottom;
  left = rect.left;
}

// Function to handle ball movement



function moveBalldileft(didistance) {
  ballposleft += didistance;
  // if (ballposleft <= 0) { // Check if the ball reaches the left edge
  //   ballposleft = 0;
  //   moveballver(standardtop); // Move the ball vertically
  // } else if (ballposleft >= window.innerWidth - l1.offsetWidth) { // Check if the ball reaches the right edge
  //   ballposleft = window.innerWidth - l1.offsetWidth;
  //   moveballver(standardtop); // Move the ball vertically
  // }
  l1.style.left = ballposleft + "px";
  counter--;

  console.log('ok');
  // // Update position variables after each movement
  updatePositionVariables();
}

let counter = 0;
let accounter = 0; 
let counterac = 0;

function moveBalldiright(acr){
   ballposleft -= acr;
   l1.style.left = ballposleft + px;
   counter++;
   return;
}



function moveballver(verdistance) {
  //  console.log(standardtop += verdistance);
  //  standardtop += verdistance;
   l1.style.top = standardtop + px;
   console.log("correct");
   console.log(verdistance);
   console.log(standardtop);
   return;
}

l1.focus();

function deletemovev () {
  document.removeEventListener('keydown', handleKeyDown);
  return;
}


function changel1 () {
  random = Math.floor(Math.random() * 2048);
  ok = false;
  while (ok != true) {
    if (random % 2) {
      ok = false;
      random = Math.floor(Math.random() * 2048);
      console.log("failed");
  }

  else if (level = true){
     acrandom = random;
     ok = true;
     console.log("passed");
     console.log(random)
  }
}
  ok = false;
}


let thatok = false;
// function switchaballgv() {

// }
updatePositionVariables()
console.log(right);
console.log(left);
// Event handler for keydown events
// Get the element
let acok = true;

let aca = true;

function doit(){
	document.addEventListener('keydown', handleKeyDown);
	updatePositionVariables();
}

function rightaddevent (){
  document.addEventListener("keydown", function(event){
     if (event.keyCode === 37){
	    moveBalldileft(-standardm);
      acokac = true;
      return;
     }

    //  else if (event.keycode === 39){
	// 	updatePositionVariables();
    // 	document.addEventListener('keydown', handleKeyDown);
    // 	updatePositionVariables();
	//  }
  })
}

function killright(){
document.removeEventListener("keydown", handleKeyDown)
leftaddevent();
}

function killleft(){
document.removeEventListener('keydown', handleKeyDown);
rightaddevent();
}
function checkposac(){
  updatePositionVariables();
if (rightaid === acrightaid){
killleft();
}

else if (rightaid === acleftaid){
killright() 
}

}

function actryagainright(){
	document.removeEventListener("keydown", handleKeyDown);
	document.addEventListener("click", function(event){

  switch(event.keyCode){
	case 39:
 
  aca = false;
  }
})
}

function actryagainleft(){
	document.removeEventListener("keydown", handleKeyDown);
	document.addEventListener("click", function(event){


	switch(event.keyCode){
	  case 37:
		aca = false;
  }
  })
}

function checker(){
     if (aca === false){
		updatePositionVariables();
  		document.addEventListener('keydown', handleKeyDown);
  		updatePositionVariables();
	 }
}


let acokac = false;



function checkright() {
	actryagainleft();
	checker();
	aca = true;
}

function checkleft() {
	actryagainright();
	checker();
	aca = true;
}
function leftaddevent (){
       document.addEventListener("keydown", function(event){
          if (event.keyCode === 39){
            console.log("q");
            updatePositionVariables();
		document.addEventListener('keydown',handleKeyDown);
		updatePositionVariables();
          }

          else if (event.keyCode === 3){
            aca = null;
          }

       })
}

function makeanumber() {

}


/////////////////////////////////////////

function checkthatleft() {
    //  if(radiookright === true){
	// 	updatePositionVariables();
	// 	document.addEventListener('keydown', handleKeyDown);
	// 	updatePositionVariables();
	//  }

	if (rightaid != -41){
		document.addEventListener('keydown', handleKeyDown);
		updatePositionVariables();
	}
}

function checkthatright() {
	if (rightaid != 39){
		updatePositionVariables();
		document.addEventListener('keydown',handleKeyDown);
		updatePositionVariables();
	}
}

function tryagain(){
if (rightaid !== acrightaid && rightaid !== acleftaid){
  updatePositionVariables();
  document.addEventListener('keydown', handleKeyDown);
  updatePositionVariables();
}
}

function killleft(){
  document.removeEventListener('keydown', handleKeyDown);
  rightaddevent()
  if (acokac){
    return;
  }
}
let radiookleft = true;
let radiookright = true;
function checkposac(){
  if (rightaid === acrightaid){
    killleft();
    if (acokac){
      return;
    }
	radiookleft = false;
  }

  else if (rightaid === acleftaid){
    killright();
    console.log("q");
	radiookright = false;
  }
  else{
    return;
    updatePositionVariables();
    document.addEventListener('keydown', handleKeyDown);
    updatePositionVariables();
  }
}
// Define the event handler function


function handleKeyDown(e) {
  updatePositionVariables();

  switch (e.keyCode) {
    case 39:
      if (bottom === bottomcheck) {
        deletemovev();
        // Ball has reached the bottom, don't move to the right
        // Add any desired logic or actions here
        updatebar();
      }
        radiookright = true;
		checkthatleft();

        checkright();
        moveBalldileft(standardm);
        updatePositionVariables();
        rightaid++;
		// tryagain();
    //     checkposac();
    //     tryagain();
    //  Rest of your existing code
    if (right === rightcheck && acok === true) {
          moveballver(standardtop);
          updatePositionVariables();
          deletemovev();
          acok = false;
        } else if (left === leftcheck && acok === true) {
          moveballver(standardtop);
          updatePositionVariables();
          deletemovev();
          acok = false;
        } 
        console.log("You")
		checkright();
		tryagain();
		checkright
      break;
    case 37:
      if (bottom === bottomcheck) {
        deletemovev();
        // Ball has reached the bottom, don't move to the right
        // Add any desired logic or actions here
        addpoints();
      }
        radiookleft = true;
	    checkleft();
      rightaid--;
        tryagain();
		checkposac();
        moveBalldiright(standardmac);
        updatePositionVariables();
        tryagain();
		checkleft();
     // Rest of your existing code
    if (right === rightcheck && acok === true) {
          moveballver(standardtop);
          updatePositionVariables();
          deletemovev();
          acok = false;
        } else if (left === leftcheck && acok === true) {
          moveballver(standardtop);
          updatePositionVariables();
          deletemovev();
          acok = false;
        } 

		checkleft();
		tryagain();
      break;
    case 40:
      if (acok === true) { 
      moveballver(standardtop);
      updatePositionVariables();
      deletemovev()
      acok = false;
      updatebar();
      console.log("downer");
      }
      console.log("down");
      adder();
      // Handle other actions for arrow down key if needed
      break;
    }
return;
}

let ballok = false;

let newballler = 2;
let l = 'l'
let t = "t"
let acnewball = l + newballler + t;
let newball = document.getElementsByClassName(acnewball);
function achandleKeyDown(e) {
  updatePositionVariables();

  switch (e.keyCode) {
    case 39:
      if (bottom === bottomcheck) {
        deletemovev();
        // Ball has reached the bottom, don't move to the right
        // Add any desired logic or actions here
        updatebar();
      }
        radiookright = true;
		checkthatleft();

        checkright();
        moveBalldileft(standardm);
        updatePositionVariables();
        rightaid++;
		// tryagain();
    //     checkposac();
    //     tryagain();
    //  Rest of your existing code
    if (right === rightcheck && acok === true) {
          moveballver(standardtop);
          updatePositionVariables();
          deletemovev();
          acok = false;
        } else if (left === leftcheck && acok === true) {
          moveballver(standardtop);
          updatePositionVariables();
          deletemovev();
          acok = false;
        } 
        console.log("You")
		checkright();
		tryagain();
		checkright
      break;
    case 37:
      if (bottom === bottomcheck) {
        deletemovev();
        // Ball has reached the bottom, don't move to the right
        // Add any desired logic or actions here
        addpoints();
      }
        radiookleft = true;
	    checkleft();
      rightaid--;
        tryagain();
		checkposac();
        moveBalldiright(standardmac);
        updatePositionVariables();
        tryagain();
		checkleft();
     // Rest of your existing code
    if (right === rightcheck && acok === true) {
          moveballver(standardtop);
          updatePositionVariables();
          deletemovev();
          acok = false;
        } else if (left === leftcheck && acok === true) {
          moveballver(standardtop);
          updatePositionVariables();
          deletemovev();
          acok = false;
        } 

		checkleft();
		tryagain();
      break;
    case 40:
      if (acok === true) { 
      l1.parentNode.removeChild(l1);
      updatePositionVariables();
      deletemovev()
      acok = false;
      updatebar();
      newballler++;
      console.log("downer");
      // executeFunctionsSequentially();
      }
      console.log("down");
      // adder();
      ballok = true;
      // Handle other actions for arrow down key if needed
      break;
    }
return;
}



let a = true;

function adder() {
      // alert()
  addball(classnameac, random, checkrand());
  // l1 = document.getElementsByClassName(acclasser + classer)[0];
  // balldefalter();
  // aceventliser();
  // acaddball(classnameac, random);
  // newball[0].style.top = acballvars[`${acballer}${acbaloops}`][`top`];
// if (a === true) {
//   a = false
//   balldefalter();
// }\[\:@^return;
}

function executeFunctionsSequentially() {
  adder();
  // Check for a specific condition to end the sequential execution
  if (ballok = true) {
    setTimeout(executeFunctionsSequentially, 1000); // Wait for 1 second before calling the function again
  }
  ballok = false;
  return;
}// if (ballok === true){
//   adder();
//   ballok = false;
// }


function aceventliser() {
  document.addEventListener('keydown', achandleKeyDown);
  return;
}

let acballvars = {
  nothing: [null]
}

let acbaloops = 1;
let acballer = 'ball';
let textball = document.getElementsByClassName(textclass)[0];

function saveballvars () {
  acbaloops++;
  textball = document.getElementsByClassName(textclass)[0];
  let styles = window.getComputedStyle(l1);
  let acstyles = window.getComputedStyle(textball);
    // Retrieve the specific styles
    let widther = styles.getPropertyValue("width");
    let textContenter = l1.textContent.trim();
    let backgroundColorer = styles.getPropertyValue("background-color");
    let lefter = styles.getPropertyValue("left");
    let toper = acstyles.getPropertyValue('top');

    // Output the styles

    acballvars[`${acballer}${acbaloops}`] = [null];
    acballvars[`${acballer}${acbaloops}`][`width`] = widther;
    acballvars[`${acballer}${acbaloops}`][`textcontent`] = textContenter;
    acballvars[`${acballer}${acbaloops}`][`backgroundcolor`] = backgroundColorer;
    acballvars[`${acballer}${acbaloops}`][`left`] = lefter;
    acballvars[`${acballer}${acbaloops}`][`top`] = toper;
    
    return;
}

function acaddball(className, tier, loops){

  saveballvars();
  // Step 1: Select the parent element
  const parentElement = document.querySelector('.ac');

  // Step 2: Create the new element
  const newElement = document.createElement('div');
  
  
  // Step 3: Optionally, add content or attributes
  // newElement.textContent = tier;
  newElement.setAttribute('class', className);
  const acparentElement = newElement;
  const acnewelement =  document.createElement('h2') ;
  newElement.style.verticalAlign = ballstyles.verticalAlign;
  newElement.style.top = ballstyles.top;
  newElement.style.border = ballstyles.border;
  newElement.style.borderRadius = ballstyles.borderRadius;
  newElement.style.zIndex = "9999";
  newElement.style.textAlign = "center";
  newElement.style.position = "relative"; 
  newElement.style.left = acballvars[`${acballer}${acbaloops}`][`left`];
  newElement.style.top = 495 + px;
  newElement.style.width = acballvars[`${acballer}${acbaloops}`][`width`];
  
  changerand();
  // Step 4: Append the new element to the parent element
      newElement.style.backgroundColor = acballvars[`${acballer}${acbaloops}`][`backgroundcolor`];
      newElement.style.height = acballvars[`${acballer}${acbaloops}`][`width`];
      newElement.style.width = wihi[`wihi${loops}`] + px;
      acnewelement.textContent = acballvars[`${acballer}${acbaloops}`][`textcontent`];
      acnewelement.style.top = acballvars[`${acballer}${acbaloops}`][`top`];
      let acclass = className + 't';
      textclass = acclass;
  // Step 4: Append the new element to the parent element
      acnewelement.setAttribute('class', acclass);
  parentElement.appendChild(newElement);
  acparentElement.appendChild(acnewelement);
  classer++;
  return;
}

// Add the event handler
function eventliser() {
  document.addEventListener('keydown', handleKeyDown);
  return;
}

// Update position variables initially
updatePositionVariables();


eventliser();



// Periodically log the position variables

// // Adjust the interval time as needed
//   if (left === "345px") {
//    document.querySelector(".ball").style.top = "565px"
//    document.querySelector(".ball").style.bottom = "30px";   
//    }

// if (level === 1) {

//   while(random !== l1a || random !== l2a || random !== l3a || random !== l4a) {
//      if(random === l1a  || random === l2a || random === l3a || random === l4a){
//         if(document.querySelector(".ball").style.top = "-25px"){
          
//         }
//     }
//      else {
//        random = Math.floor(Math.random() * 16) + 1;
//     }
//  }
//  }


// //end of code (js)

function cons(){
  console.log("finished with exit status 0");
  return 0;
}

cons();